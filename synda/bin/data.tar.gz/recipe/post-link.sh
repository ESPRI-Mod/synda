#!/bin/bash
echo $HOME >> $PREFIX/.messages.txt